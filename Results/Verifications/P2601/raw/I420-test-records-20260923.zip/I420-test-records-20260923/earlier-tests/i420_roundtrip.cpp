#include <cstdio>
#include <vector>
#include "kleidicv/kleidicv.h"
int main() {
  int failures=0;
  for (size_t w : {2,3,4,5}) for(size_t h : {4,5,6}) {
    size_t stride=w+4;
    std::vector<unsigned char> rgb(w*h*3,128), yuv(stride*(h+4),0), out(w*h*3,0);
    auto fmt=KLEIDICV_COLOR_CONVERSION_FMT_YUV420P;
    auto a=kleidicv_rgb_to_yuv_u8(rgb.data(),w*3,yuv.data(),stride,w,h,fmt);
    auto b=kleidicv_yuv_to_rgb_u8(yuv.data(),stride,out.data(),w*3,w,h,fmt);
    size_t bad=0,first=out.size();
    for(size_t i=0;i<out.size();++i) if(out[i]<127 || out[i]>129) { ++bad; if(first==out.size()) first=i; }
    std::printf("%zux%zu stride=%zu encode=%d decode=%d bad_channels=%zu",w,h,stride,int(a),int(b),bad);
    if(bad) std::printf(" first_pixel=(%u,%u,%u)",out[first/3*3],out[first/3*3+1],out[first/3*3+2]);
    std::puts("");
    failures+=(a!=KLEIDICV_OK || b!=KLEIDICV_OK || bad>0);
  }
  return failures?1:0;
}
