from pathlib import Path
import shlex, subprocess
root=Path('/tmp/build3/test/api')
a=shlex.split((root/'CMakeFiles/kleidicv-api-test.dir/link.txt').read_text())
a=[x for x in a if not x.startswith('-Wl,--dependency-file=')]
a[a.index('-o')+1]='/tmp/retest4-common-api'
a=[x.replace('../../kleidicv/libkleidicv.a','/tmp/retest4-build/kleidicv/libkleidicv.a').replace('../../kleidicv_thread/libkleidicv_thread.a','/tmp/retest4-build/kleidicv_thread/libkleidicv_thread.a') for x in a]
subprocess.run(a,cwd=root,check=True)
