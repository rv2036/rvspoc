// Frozen evaluation harness. Original reference below copied verbatim from
// KleidiCV 26.03 test/api/test_yuv420p_to_rgb.cpp.
// SPDX-FileCopyrightText: 2025 Arm Limited and/or its affiliates
// SPDX-License-Identifier: Apache-2.0
#include <algorithm>
#include <limits>
#include <vector>
#include <cstdint>
#include <cstdio>
#include "kleidicv/kleidicv.h"
class Reference { public:
  static uint8_t saturate_cast_s32_to_u8(int32_t rhs) {
    return static_cast<uint8_t>(
        std::min(std::max(0, rhs),
                 static_cast<int32_t>(std::numeric_limits<uint8_t>::max())));
  }
  void calculate_referenc(const uint8_t* src, size_t src_stride, uint8_t* dst,
                          size_t dst_stride, size_t width, size_t height,
                          bool is_yv12, bool BGR, size_t channels) {
    // this will the pointer to u plane
    const uint8_t* u = src + src_stride * height;
    // this will the pointer to v plane
    const uint8_t* v = src + src_stride * (height + height / 4) +
                       (width / 2) * ((height % 4) / 2);
    size_t ustepIdx = 0;
    size_t vstepIdx = height % 4 == 2 ? 1 : 0;
    size_t uvsteps[2] = {width / 2, static_cast<int>(src_stride) - width / 2};
    size_t usIdx = ustepIdx, vsIdx = vstepIdx;
    const uint8_t* y1 = src;
    const uint8_t* u1 = u;
    const uint8_t* v1 = v;
    for (size_t h = 0; h < height; h++) {
      for (size_t w = 0; w < width; w++) {
        // NOLINTBEGIN(clang-analyzer-core.uninitialized.Assign)
        int32_t y = y1[h * src_stride + w];
        // NOLINTEND(clang-analyzer-core.uninitialized.Assign)
        y = std::max(0, y - 16);
        int32_t u = u1[w >> 1];
        u -= 128;
        int32_t v = v1[w >> 1];
        v -= 128;
        if (is_yv12) {
          std::swap(u, v);
        }
        int32_t r = ((1220542 * y) + (1673527 * v) + (1 << 19)) >> 20;
        int32_t g =
            ((1220542 * y) - (409993 * u) - (852492 * v) + (1 << 19)) >> 20;
        int32_t b = ((1220542 * y) + (2116026 * u) + (1 << 19)) >> 20;

        uint8_t r_u8 = saturate_cast_s32_to_u8(r);
        uint8_t g_u8 = saturate_cast_s32_to_u8(g);
        uint8_t b_u8 = saturate_cast_s32_to_u8(b);

        if (BGR) {
          std::swap(b_u8, r_u8);
        }
        dst[h * dst_stride + w * channels + 0] = r_u8;
        dst[h * dst_stride + w * channels + 1] = g_u8;
        dst[h * dst_stride + w * channels + 2] = b_u8;
        if (channels == 4) {
          dst[h * dst_stride + w * channels + 3] = 0xff;
        }
      }
      if ((h % 2) == 1) {
        u1 += uvsteps[(usIdx++) & 1];
        v1 += uvsteps[(vsIdx++) & 1];
      }
    }
  }
};
struct Counts { int cases=0,failed=0; } original,even_decode,even_encode;
unsigned rng=0x12345678;
uint8_t next_byte() { rng^=rng<<13; rng^=rng>>17; rng^=rng<<5;return uint8_t(rng); }
kleidicv_color_conversion_t format(int c,bool vu,bool bgr) {
 return static_cast<kleidicv_color_conversion_t>(KLEIDICV_COLOR_CONVERSION_FMT_YUV420P |
 (c==4?KLEIDICV_COLOR_CONVERSION_FLAG_ALPHA:0) |
 (vu?KLEIDICV_COLOR_CONVERSION_FLAG_VU:0) |
 (bgr?KLEIDICV_COLOR_CONVERSION_FLAG_BGR:0));
}
void decode_case(const char* group,Counts &count,size_t w,size_t h,size_t pad,int c,bool vu,bool bgr) {
 size_t stride=w+pad, dst_stride=w*c;
 std::vector<uint8_t> src(stride*(h+(h+1)/2+4)),expected(dst_stride*h),out(dst_stride*h,0);
 for(auto &v:src)v=next_byte();
 Reference{}.calculate_referenc(src.data(),stride,expected.data(),dst_stride,w,h,vu,bgr,c);
 auto status=kleidicv_yuv_to_rgb_u8(src.data(),stride,out.data(),dst_stride,w,h,format(c,vu,bgr));
 size_t mismatches=0, first=0;
 for(size_t i=0;i<out.size();++i) if(out[i]!=expected[i]) { if(!mismatches)first=i; ++mismatches; }
 ++count.cases; if(status!=KLEIDICV_OK||mismatches) {
  ++count.failed;
  std::printf("FAIL %s w=%zu h=%zu stride=%zu channels=%d vu=%d bgr=%d status=%d mismatch=%zu first=%zu got=%u expected=%u\n",group,w,h,stride,c,vu,bgr,int(status),mismatches,first,out[first],expected[first]);
 }
}
void encode_case(size_t w,size_t h,size_t pad,int c,bool vu,bool bgr) {
 size_t stride=w+pad;
 std::vector<uint8_t> src(w*h*c,128),out(stride*(h+h/2+4),0);
 auto status=kleidicv_rgb_to_yuv_u8(src.data(),w*c,out.data(),stride,w,h,format(c,vu,bgr));
 size_t mismatches=0, first=0;
 // Original 26.03 encoder's chroma addresses, copied from rgb_to_yuv420_neon.h.
 // Gray RGB has U=V=128, irrespective of channel order; inspect only active chroma bytes.
 for(size_t y=0;y<h;y+=2) {
  size_t u=stride*h+stride*(y/4)+((y/2)%2)*((w+1)/2);
  size_t v=stride*h+stride*((y+h+1)/4)+(((y+h+1)/2)%2)*((w+1)/2);
  for(size_t x=0;x<(w+1)/2;++x) for(size_t index:{u+x,v+x})
   if(out[index]!=128) { if(!mismatches)first=index; ++mismatches; }
 }
 ++even_encode.cases; if(status!=KLEIDICV_OK||mismatches) {
  ++even_encode.failed;
  std::printf("FAIL even_encode w=%zu h=%zu stride=%zu channels=%d vu=%d bgr=%d status=%d mismatch=%zu first=%zu got=%u expected=128\n",w,h,stride,c,vu,bgr,int(status),mismatches,first,out[first]);
 }
}
int main() {
 for(size_t w:{2,4,6,18,33})for(size_t h:{2,5,11,16})for(int c:{3,4})for(bool vu:{false,true})for(bool bgr:{false,true})
  decode_case("original_parameters",original,w,h,4,c,vu,bgr);
 for(size_t w:{2,4,6,18,34})for(size_t h:{2,4,6,8,10,12})for(size_t pad:{0,4})for(int c:{3,4})for(bool vu:{false,true})for(bool bgr:{false,true}) {
  decode_case("even_decode",even_decode,w,h,pad,c,vu,bgr);
  encode_case(w,h,pad,c,vu,bgr);
 }
 std::printf("SUMMARY original_parameters total=%d passed=%d failed=%d\n",original.cases,original.cases-original.failed,original.failed);
 std::printf("SUMMARY even_decode total=%d passed=%d failed=%d\n",even_decode.cases,even_decode.cases-even_decode.failed,even_decode.failed);
 std::printf("SUMMARY even_encode total=%d passed=%d failed=%d\n",even_encode.cases,even_encode.cases-even_encode.failed,even_encode.failed);
 return original.failed||even_decode.failed||even_encode.failed?1:0;
}
