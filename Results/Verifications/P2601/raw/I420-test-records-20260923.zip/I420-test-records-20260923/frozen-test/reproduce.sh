#!/bin/bash
# Run on A210 from a directory containing exact git archives src3/ and src4/.
# Place i420_reference_test.cpp in the same directory.
set -eu
for mode in rvv scalar; do
  if [ "$mode" = rvv ]; then enable=ON; flags='-fno-tree-vectorize'; else enable=OFF; flags='-fno-tree-vectorize -march=rv64gc'; fi
  for id in 3 4; do
    cmake -S "src$id" -B "$mode$id" -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS="$flags" -DKLEIDICV_ENABLE_RVV="$enable" -DKLEIDICV_BUILD_TESTS=OFF -DKLEIDICV_BUILD_EXAMPLES=OFF -DKLEIDICV_BENCHMARK=OFF
    cmake --build "$mode$id" --parallel 2 --target kleidicv
    g++ -O2 -std=c++17 -march=rv64gc -fno-tree-vectorize -I"src$id/kleidicv/include" -I"$mode$id/kleidicv/include" i420_reference_test.cpp "$mode$id/kleidicv/libkleidicv.a" -o "test-$mode$id"
    code=0
    "./test-$mode$id" > "test-$mode$id.log" || code=$?
    echo "$mode$id exit=$code"
    tail -3 "test-$mode$id.log"
  done
done
