from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
count=0
for line in (root/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    path=(root/name).resolve()
    assert path.is_relative_to(root),name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,name
    count+=1
summary=json.loads((root/'frozen-test/summary.json').read_text())
for mode in ('rvv','scalar'):
    for ident in (3,4):
        lines=(root/f'frozen-test/test-{mode}{ident}.log').read_text().splitlines()
        for group,values in summary[f'{mode}{ident}'].items():
            assert sum(line.startswith('FAIL '+group+' ') for line in lines)==values['failed']
            assert values['passed']+values['failed']==values['total']
print(f'PASS: {count} file hashes; all failure counts match summaries.')
